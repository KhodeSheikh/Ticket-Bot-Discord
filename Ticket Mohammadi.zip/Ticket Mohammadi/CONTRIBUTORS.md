
<!-- ALL-CONTRIBUTORS-BADGE:START - Do not remove or modify this section -->
[![All Contributors](https://img.shields.io/badge/all_contributors-36-orange.svg?style=flat-square)](#contributors-)
<!-- ALL-CONTRIBUTORS-BADGE:END -->

## Contributors ✨

Thanks goes to these wonderful people ([emoji key](https://allcontributors.org/docs/en/emoji-key)):

<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
  <tbody>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://eartharoid.me/"><img src="https://avatars.githubusercontent.com/u/20905071?v=4?s=100" width="100px;" alt="Isaac"/><br /><sub><b>Isaac</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=eartharoid" title="Code">💻</a> <a href="#maintenance-eartharoid" title="Maintenance">🚧</a> <a href="https://github.com/discord-tickets/bot/commits?author=eartharoid" title="Documentation">📖</a> <a href="https://github.com/discord-tickets/bot/pulls?q=is%3Apr+reviewed-by%3Aeartharoid" title="Reviewed Pull Requests">👀</a> <a href="#design-eartharoid" title="Design">🎨</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/iDrunK65"><img src="https://avatars.githubusercontent.com/u/25486774?v=4?s=100" width="100px;" alt="iDrunK65"/><br /><sub><b>iDrunK65</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=iDrunK65" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/nicholasyoannou"><img src="https://avatars.githubusercontent.com/u/29736141?v=4?s=100" width="100px;" alt="Nicholas Y."/><br /><sub><b>Nicholas Y.</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=nicholasyoannou" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/RhysB"><img src="https://avatars.githubusercontent.com/u/25815220?v=4?s=100" width="100px;" alt="Rhys B"/><br /><sub><b>Rhys B</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=RhysB" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/mgsi100"><img src="https://avatars.githubusercontent.com/u/36934590?v=4?s=100" width="100px;" alt="Sébastien Guzman"/><br /><sub><b>Sébastien Guzman</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=mgsi100" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/iFusionFr"><img src="https://avatars.githubusercontent.com/u/31099360?v=4?s=100" width="100px;" alt="iFusion"/><br /><sub><b>iFusion</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=iFusionFr" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://fivepixels.me/"><img src="https://avatars.githubusercontent.com/u/37427166?v=4?s=100" width="100px;" alt="FivePixels"/><br /><sub><b>FivePixels</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=FivePixels" title="Code">💻</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://davidcralph.co.uk/"><img src="https://avatars.githubusercontent.com/u/14052956?v=4?s=100" width="100px;" alt="David Ralph"/><br /><sub><b>David Ralph</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=davidcralph" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/OliverCordingl1"><img src="https://avatars.githubusercontent.com/u/19516518?v=4?s=100" width="100px;" alt="Oliver Cordingley"/><br /><sub><b>Oliver Cordingley</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=OliverCordingl1" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/itzJOHv"><img src="https://avatars.githubusercontent.com/u/68508885?v=4?s=100" width="100px;" alt="itzJOHv"/><br /><sub><b>itzJOHv</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=itzJOHv" title="Code">💻</a> <a href="#question-itzJOHv" title="Answering Questions">💬</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/CanerBaba25"><img src="https://avatars.githubusercontent.com/u/33705518?v=4?s=100" width="100px;" alt="CanerBaba25"/><br /><sub><b>CanerBaba25</b></sub></a><br /><a href="#translation-CanerBaba25" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/Felimir"><img src="https://avatars.githubusercontent.com/u/52141188?v=4?s=100" width="100px;" alt="Fel"/><br /><sub><b>Fel</b></sub></a><br /><a href="#translation-Felimir" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/donzee529"><img src="https://avatars.githubusercontent.com/u/43678009?v=4?s=100" width="100px;" alt="Doniel"/><br /><sub><b>Doniel</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=donzee529" title="Documentation">📖</a> <a href="https://github.com/discord-tickets/bot/commits?author=donzee529" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://puneetgopinath.github.io/"><img src="https://avatars.githubusercontent.com/u/76863199?v=4?s=100" width="100px;" alt="Puneet Gopinath"/><br /><sub><b>Puneet Gopinath</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=PuneetGopinath" title="Code">💻</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/thevisuales"><img src="https://avatars.githubusercontent.com/u/6569806?v=4?s=100" width="100px;" alt="thevisuales"/><br /><sub><b>thevisuales</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=thevisuales" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://rooray.xyz"><img src="https://avatars.githubusercontent.com/u/86845749?v=4?s=100" width="100px;" alt="RooRay"/><br /><sub><b>RooRay</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=RooRay" title="Documentation">📖</a> <a href="https://github.com/discord-tickets/bot/commits?author=RooRay" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://foxco-network.de"><img src="https://avatars.githubusercontent.com/u/54017453?v=4?s=100" width="100px;" alt="FoxXxHater"/><br /><sub><b>FoxXxHater</b></sub></a><br /><a href="#platform-FoxXxHater" title="Packaging/porting to new platform">📦</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://adminrat.codes"><img src="https://avatars.githubusercontent.com/u/24538037?v=4?s=100" width="100px;" alt="AdminRAT"/><br /><sub><b>AdminRAT</b></sub></a><br /><a href="#platform-AdminRAT" title="Packaging/porting to new platform">📦</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://c43721.dev"><img src="https://avatars.githubusercontent.com/u/55610086?v=4?s=100" width="100px;" alt="c43721"/><br /><sub><b>c43721</b></sub></a><br /><a href="#platform-c43721" title="Packaging/porting to new platform">📦</a> <a href="https://github.com/discord-tickets/bot/commits?author=c43721" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/n1kkl"><img src="https://avatars.githubusercontent.com/u/100782498?v=4?s=100" width="100px;" alt="Niklas"/><br /><sub><b>Niklas</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=n1kkl" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/Uzurka"><img src="https://avatars.githubusercontent.com/u/101745008?v=4?s=100" width="100px;" alt="Uzurka"/><br /><sub><b>Uzurka</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/issues?q=author%3AUzurka" title="Bug reports">🐛</a> <a href="#platform-Uzurka" title="Packaging/porting to new platform">📦</a> <a href="#translation-Uzurka" title="Translation">🌍</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/iNOEEL"><img src="https://avatars.githubusercontent.com/u/26775559?v=4?s=100" width="100px;" alt="Noel Horvath"/><br /><sub><b>Noel Horvath</b></sub></a><br /><a href="#translation-iNOEEL" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/Gdanycz"><img src="https://avatars.githubusercontent.com/u/60316826?v=4?s=100" width="100px;" alt="Gdany"/><br /><sub><b>Gdany</b></sub></a><br /><a href="#translation-Gdanycz" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/Chaosfelix4451"><img src="https://avatars.githubusercontent.com/u/46029764?v=4?s=100" width="100px;" alt="Chaosfelix4451"/><br /><sub><b>Chaosfelix4451</b></sub></a><br /><a href="#translation-Chaosfelix4451" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/GeckoBoy84"><img src="https://avatars.githubusercontent.com/u/67899387?v=4?s=100" width="100px;" alt="GeckoBoy84"/><br /><sub><b>GeckoBoy84</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/issues?q=author%3AGeckoBoy84" title="Bug reports">🐛</a> <a href="#ideas-GeckoBoy84" title="Ideas, Planning, & Feedback">🤔</a> <a href="#question-GeckoBoy84" title="Answering Questions">💬</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/Manfred-exe"><img src="https://avatars.githubusercontent.com/u/81268335?v=4?s=100" width="100px;" alt="Manfred.exe"/><br /><sub><b>Manfred.exe</b></sub></a><br /><a href="#translation-Manfred-exe" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/Thomasthegama"><img src="https://avatars.githubusercontent.com/u/70441539?v=4?s=100" width="100px;" alt="Thomasthegama"/><br /><sub><b>Thomasthegama</b></sub></a><br /><a href="#translation-Thomasthegama" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/VinDotRun"><img src="https://avatars.githubusercontent.com/u/28811713?v=4?s=100" width="100px;" alt="Vin"/><br /><sub><b>Vin</b></sub></a><br /><a href="#translation-VinDotRun" title="Translation">🌍</a> <a href="https://github.com/discord-tickets/bot/issues?q=author%3AVinDotRun" title="Bug reports">🐛</a> <a href="https://github.com/discord-tickets/bot/commits?author=VinDotRun" title="Code">💻</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/M4rlus"><img src="https://avatars.githubusercontent.com/u/43551856?v=4?s=100" width="100px;" alt="Marius"/><br /><sub><b>Marius</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/commits?author=M4rlus" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/cccc9803"><img src="https://avatars.githubusercontent.com/u/30467450?v=4?s=100" width="100px;" alt="cccc9803"/><br /><sub><b>cccc9803</b></sub></a><br /><a href="#translation-cccc9803" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/billy99816609"><img src="https://avatars.githubusercontent.com/u/54208828?v=4?s=100" width="100px;" alt="billy99816609"/><br /><sub><b>billy99816609</b></sub></a><br /><a href="#translation-billy99816609" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/Umeaboy"><img src="https://avatars.githubusercontent.com/u/714473?v=4?s=100" width="100px;" alt="Kristoffer Grundström"/><br /><sub><b>Kristoffer Grundström</b></sub></a><br /><a href="#translation-Umeaboy" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://zukrein.xyz"><img src="https://avatars.githubusercontent.com/u/73394120?v=4?s=100" width="100px;" alt="Arda Samed Çelik"/><br /><sub><b>Arda Samed Çelik</b></sub></a><br /><a href="#translation-zukreindev" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/creeperita09"><img src="https://avatars.githubusercontent.com/u/97898994?v=4?s=100" width="100px;" alt="creeperita09"/><br /><sub><b>creeperita09</b></sub></a><br /><a href="#translation-creeperita09" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/Luzifix"><img src="https://avatars.githubusercontent.com/u/7042325?v=4?s=100" width="100px;" alt="Luzifix"/><br /><sub><b>Luzifix</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/issues?q=author%3ALuzifix" title="Bug reports">🐛</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/DominicTheD3v"><img src="https://avatars.githubusercontent.com/u/119626487?v=4?s=100" width="100px;" alt="DominicTheD3v"/><br /><sub><b>DominicTheD3v</b></sub></a><br /><a href="https://github.com/discord-tickets/bot/issues?q=author%3ADominicTheD3v" title="Bug reports">🐛</a> <a href="https://github.com/discord-tickets/bot/commits?author=DominicTheD3v" title="Code">💻</a></td>
    </tr>
  </tbody>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<!-- ALL-CONTRIBUTORS-LIST:END -->

This project follows the [all-contributors](https://github.com/all-contributors/all-contributors) specification. [Contributions](https://github.com/discord-tickets/.github/blob/main/CONTRIBUTING.md) of any kind are welcome, read [CONTRIBUTING.md](https://github.com/discord-tickets/.github/blob/main/CONTRIBUTING.md).
